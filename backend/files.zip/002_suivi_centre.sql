-- 002_suivi_centre.sql
-- Suivi Ooredoo Centre : négociateurs, règles d'avancement, colonnes de suivi sur sites.
-- 100 % additif : ne supprime et ne modifie aucune donnée existante.
-- Peut être rejoué sans risque (IF NOT EXISTS / ON CONFLICT).

BEGIN;

-- 1. Négociateurs (chargés d'acquisition ; un freelance n'a pas forcément de compte utilisateur)
CREATE TABLE IF NOT EXISTS negotiators (
    id          SERIAL PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE,
    kind        TEXT NOT NULL DEFAULT 'INTERNE'
                CHECK (kind IN ('INTERNE', 'FREELANCE', 'OPERATEUR')),
    user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 2. Règles : texte d'avancement du suivi -> catégorie / étape / organisme attendu / statut
--    (table modifiable : changer une ligne suffit, sans toucher au code)
CREATE TABLE IF NOT EXISTS progress_rules (
    id            SERIAL PRIMARY KEY,
    progress_key  TEXT NOT NULL UNIQUE,   -- avancement en majuscules, espaces normalisés
    category      TEXT NOT NULL CHECK (category IN ('BOUCLE', 'EN_COURS', 'BLOQUE')),
    stage         TEXT,
    waiting_for   TEXT,
    status_id     INTEGER REFERENCES site_status(id),  -- NULL = statut inchangé
    needs_review  BOOLEAN NOT NULL DEFAULT FALSE
);

INSERT INTO progress_rules (progress_key, category, stage, waiting_for, status_id, needs_review) VALUES
  ('BOUCLEE', 'BOUCLE', 'BOUCLEE', NULL, 16, FALSE),
  ('ATTENTE DOC B', 'EN_COURS', 'DOC_B', NULL, 4, FALSE),
  ('ATTENTE CCT', 'EN_COURS', 'CCT', 'CCT', NULL, FALSE),
  ('ATTENTE TSS', 'EN_COURS', 'TSS', 'TSS', NULL, FALSE),
  ('BLOQUÉ', 'BLOQUE', 'BLOCAGE', NULL, 20, FALSE),
  ('ATTENTE SIGNATURE CONTRAT', 'EN_COURS', 'CONTRAT', NULL, 15, FALSE),
  ('(VIDE)', 'EN_COURS', NULL, NULL, NULL, FALSE),
  ('ATTENTE PV CCT', 'EN_COURS', 'CCT', 'CCT', NULL, FALSE),
  ('ATTENTE SIGNATURE DE CONTRAT', 'EN_COURS', 'CONTRAT', NULL, 15, FALSE),
  ('BLOQUE', 'BLOQUE', 'BLOCAGE', NULL, 20, FALSE),
  ('AVIS DEFAVORABLE VERBAL DU P/APC', 'BLOQUE', 'BLOCAGE', 'APC', NULL, FALSE),
  ('ATTENTE ENQUETTE FONCIERE', 'EN_COURS', 'AUTORISATION', NULL, NULL, FALSE),
  ('ATTENTE PV CCT/ APS', 'EN_COURS', 'CCT', 'CCT', NULL, FALSE),
  ('ATTENTE RETOUR OPGI', 'EN_COURS', 'ORGANISME', 'OPGI', NULL, FALSE),
  ('VISITE REPORTEE', 'EN_COURS', 'VISITE', NULL, NULL, FALSE),
  ('ATTENTE DEMANDE CCT', 'EN_COURS', 'CCT', 'CCT', NULL, FALSE),
  ('CCT DEFAVORABLE / ATTENTE RETOUR RAIL TELECOM', 'BLOQUE', 'CCT', 'RAIL TELECOM', NULL, FALSE),
  ('CCT DEFAVORABLE', 'BLOQUE', 'CCT', NULL, NULL, FALSE),
  ('ATTENTE AUTORISATION DJS', 'EN_COURS', 'AUTORISATION', 'DJS', NULL, FALSE),
  ('ATTENTE RETOUR RAIL TELECOM', 'EN_COURS', 'ORGANISME', 'RAIL TELECOM', NULL, FALSE),
  ('ATTENTE AUTORISATION', 'EN_COURS', 'AUTORISATION', NULL, NULL, FALSE),
  ('TSS SURVEY', 'EN_COURS', 'TSS', NULL, NULL, FALSE),
  ('ATTENTE DOSSIER EXPERT GEOMETRE POUR DEPOT.', 'EN_COURS', 'AUTORISATION', NULL, NULL, FALSE),
  ('ATTENTE AUTORISATION DE CONSTRUIRE', 'EN_COURS', 'AUTORISATION', NULL, NULL, FALSE),
  ('PAS DE CANDIDATS', 'BLOQUE', 'BLOCAGE', NULL, NULL, FALSE),
  ('ATTENTE RETOUR DOMAINES', 'EN_COURS', 'ORGANISME', 'DOMAINES', NULL, FALSE),
  ('PREACQUIS', 'BOUCLE', 'PREACQUIS', NULL, NULL, TRUE),
  ('ATTENTE RETOUR DW ET DRAG', 'EN_COURS', 'ORGANISME', 'DW / DRAG', NULL, FALSE),
  ('PREACQUIS ATTENTE AUTORISATION AADL', 'BOUCLE', 'PREACQUIS', 'AADL', NULL, TRUE),
  ('ATTENTE DOC B / ATTENTE CONFIRMATION DU CANDIDAT/ REFUS CDT', 'BLOQUE', 'DOC_B', NULL, NULL, TRUE),
  ('ECHEC OPPOSITION', 'BLOQUE', 'BLOCAGE', NULL, NULL, FALSE),
  ('ECHEC ACQUISITION', 'BLOQUE', 'BLOCAGE', NULL, NULL, FALSE),
  ('ATTENTE TSS SURVEY', 'EN_COURS', 'TSS', 'TSS', NULL, FALSE),
  ('PAS DE CANDIDAT', 'BLOQUE', 'BLOCAGE', NULL, NULL, FALSE),
  ('ATTENTE SIGNATURE CONVENTION', 'EN_COURS', 'CONTRAT', NULL, 15, FALSE),
  ('ATTENTE COFIRMATION NUMILOG', 'EN_COURS', 'ORGANISME', 'NUMILOG', NULL, FALSE),
  ('ATTENTE DEMANDE APC', 'EN_COURS', 'AUTORISATION', 'APC', NULL, FALSE),
  ('ATTENTE DOC B/TSS/AUTORISATION', 'EN_COURS', 'DOC_B', 'TSS', NULL, FALSE),
  ('ATTENTE KO', 'BOUCLE', 'KICKOFF', NULL, NULL, TRUE),
  ('ATTENTE APS', 'EN_COURS', 'APS', NULL, 9, FALSE),
  ('ATTENTE RETOUR DIRECTION DES MOUDJAHIDINES', 'EN_COURS', 'ORGANISME', 'DIRECTION DES MOUDJAHIDINES', NULL, FALSE)
ON CONFLICT (progress_key) DO NOTHING;

-- 3. Colonnes de suivi sur sites (toutes facultatives)
ALTER TABLE sites
    ADD COLUMN IF NOT EXISTS project              TEXT,
    ADD COLUMN IF NOT EXISTS acquisition_entity   TEXT,
    ADD COLUMN IF NOT EXISTS negotiator_id        INTEGER REFERENCES negotiators(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS owner_type           TEXT,
    ADD COLUMN IF NOT EXISTS owner_phone          TEXT,
    ADD COLUMN IF NOT EXISTS commune_name         TEXT,
    ADD COLUMN IF NOT EXISTS rent_negotiated      NUMERIC(12, 2),
    ADD COLUMN IF NOT EXISTS gps_delta_m          DOUBLE PRECISION,
    ADD COLUMN IF NOT EXISTS doc_a_date           DATE,
    ADD COLUMN IF NOT EXISTS doc_b_date           DATE,
    ADD COLUMN IF NOT EXISTS doc_b_delay_days     INTEGER,
    ADD COLUMN IF NOT EXISTS tss_date             DATE,
    ADD COLUMN IF NOT EXISTS contract_date        DATE,
    ADD COLUMN IF NOT EXISTS site_typology        TEXT,   -- GF / RT / MICRO
    ADD COLUMN IF NOT EXISTS site_model           TEXT,   -- P9, P12, P15, P45, P60...
    ADD COLUMN IF NOT EXISTS progress_raw         TEXT,   -- texte d'avancement d'origine
    ADD COLUMN IF NOT EXISTS progress_category    TEXT
        CHECK (progress_category IN ('BOUCLE', 'EN_COURS', 'BLOQUE')),
    ADD COLUMN IF NOT EXISTS progress_stage       TEXT,
    ADD COLUMN IF NOT EXISTS waiting_for          TEXT;

CREATE INDEX IF NOT EXISTS idx_sites_negotiator ON sites (negotiator_id);
CREATE INDEX IF NOT EXISTS idx_sites_progress_category ON sites (progress_category);
CREATE INDEX IF NOT EXISTS idx_sites_project ON sites (project);

-- 4. Sécurité : accès fermé via l'API de données Supabase (le backend, rôle postgres, reste autorisé)
ALTER TABLE negotiators    ENABLE ROW LEVEL SECURITY;
ALTER TABLE progress_rules ENABLE ROW LEVEL SECURITY;

COMMIT;
